ArtBox
******
These free patterns are linkware.
Please link credit if you use them.

URL: http://community.livejournal.com/artbox/
or   <lj user="artbox"> on your LJ resources info.

Thank you.



